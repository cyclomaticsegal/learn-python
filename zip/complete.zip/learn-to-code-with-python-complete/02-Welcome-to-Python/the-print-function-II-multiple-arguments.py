print("A", "B")
print("C", "D", "E", "F")

print(5 + 3, 2 - 8)
print(5 + 3, 2 - 8, 3 + 1)

print("Hello", 10, 3.14)