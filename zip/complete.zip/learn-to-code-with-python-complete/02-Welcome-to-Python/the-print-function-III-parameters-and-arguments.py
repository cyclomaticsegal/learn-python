print("ABC", "DEF", "XYZ")
print("ABC", "DEF", "XYZ", sep="!")
print("ABC", "DEF", "XYZ", sep="--*--")
print("ABC", "DEF", "XYZ", sep=" ")

print("ABC", "DEF", "XYZ", "!")

print("Hello", "Goodbye", end="!&*")
print("Hello")

print("A", "B", "C", sep="**", end="#")
print("A", "B", "C", end="#", sep="**")