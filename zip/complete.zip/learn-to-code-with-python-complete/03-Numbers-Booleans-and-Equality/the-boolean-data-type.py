print(True)
print(False)
print("True")
print("False")

print(5 == 5)
print(5 == 8)
print(8.3 == 8.3)
print(8.3 == 4.1)
print(5 == "5")

print("ham" == "ham")
print("ham" == "bacon")
print("ham" == "Ham")
print("5" == "5")
print("" == "")
print("!==*" == "!==*")

print(5 == 5.0)
print(5 == 5.1)

print(True == True)
print(False == False)
print(True == False)

print(10 != 8)
print(10 != 10)
print("music" != "music")
print("music" != "noise")
print("music" != "Music")

print(10 != "10")
print(8.3 != 9.8)
print(3.0 != 3)