a = 1
a = a + 2
print(a)

a = 1
a += 2
print(a)

word = "race"
word = word + "car"
print(word)

word = "race"
word += "car"
print(word)

b = 5
b = b * 3
print(b)

b = 5
b *= 3
print(b)

# -=
# /=