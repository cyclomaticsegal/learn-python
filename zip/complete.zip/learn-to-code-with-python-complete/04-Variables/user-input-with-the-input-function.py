# first_name = input("What's your first name? ")
# print("It's nice to meet you,", first_name)

# Prompt the user for two numbers, one at a time
# The numbers will be received as strings
# Convert both numbers to integers
# Print a message that includes the sum of the two numbers
print("Let me help you add 2 numbers")
first_number = int(input("Enter your first number! "))
second_number = int(input("Enter your second number! "))
print("The total is", first_number + second_number)