topic = "programming"

print(topic[-1])
print(topic[-2])
print(topic[-5])

# print(topic[-100])