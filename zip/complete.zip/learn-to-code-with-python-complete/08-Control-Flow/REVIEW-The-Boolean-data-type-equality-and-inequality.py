handsome = True
admin = False
print(2 < 4)
print(7 >= 8)
result = 2 < 4
print(result)

print("xbox" == "xbox")
print("xbox" == "playstation")
print("xbox" == "Xbox")
print(5 == 5)
print(5 == 7)

print(4 != 5)
print(5 != 5)
print("Boris" != "boris")
print("Boris" != "Boris")
print(True != False)
print(True != True)