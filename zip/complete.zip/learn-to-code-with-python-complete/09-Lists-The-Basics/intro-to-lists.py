empty = []
empty = list()

sodas = ["Coke", "Pepsi", "Dr. Pepper"]
print(len(sodas))

quarterly_revenues = [15000, 12000, 9000, 20000]
print(len(quarterly_revenues))

stock_prices = [343.26, 89.25]
print(len(stock_prices))

user_settings = [True, False, False, True, False]
print(len(user_settings))