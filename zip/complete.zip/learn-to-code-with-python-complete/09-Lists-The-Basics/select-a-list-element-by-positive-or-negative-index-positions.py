print("organic"[5])

web_browsers = ["Chrome", "Firefox", "Safari", "Opera", "Edge"]
print(web_browsers[0])
print(web_browsers[1])
print(web_browsers[4])

# print(web_browsers[10])
print(web_browsers[2][3])

presidents = ["Washington", "Adams", "Jefferson"]
print(presidents[-1])
print(presidents[-2])
print(presidents[-3])

# print(presidents[-20])