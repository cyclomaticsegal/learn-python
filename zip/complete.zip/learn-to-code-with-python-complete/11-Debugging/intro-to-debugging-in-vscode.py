print("Welcome to my program")

def do_fun_stuff():
    a = 20
    print("Hello")
    print("Goodbye")
    a = 25
    return a

final_value = do_fun_stuff()
print(do_fun_stuff())