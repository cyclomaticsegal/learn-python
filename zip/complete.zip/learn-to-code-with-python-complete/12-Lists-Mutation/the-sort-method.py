temperatures = [40, 28, 52, 66, 35]
temperatures.sort()
temperatures.reverse()
print(temperatures)

coffees = ["Latte", "Espresso", "Macchiato", "Frappucino"]
coffees.sort()
coffees.reverse()
print(coffees)

coffees = ["Latte", "espresso", "macchiato", "Frappucino"]
coffees.sort()
print(coffees)


coffees = ["Latte", "Espresso", "Macchiato", "Frappucino"]
print(sorted(coffees))
print(coffees)