users = "Bob, Dave, John, Sue, Randy, Meg"

print(users.split(", "))
print(users.split(", ", 3))

sentence = "I am learning how to code"
words = sentence.split(" ")
print(words)