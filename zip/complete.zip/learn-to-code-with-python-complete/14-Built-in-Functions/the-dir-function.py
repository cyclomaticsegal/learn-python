# print(dir([]))
print(dir("pasta"))

print(len("pasta"))
print("pasta".__len__())

print("st" in "pasta")
print("pasta".__contains__("st"))

print("pasta" + " and meatballs")
print("pasta".__add__(" and meatballs"th))