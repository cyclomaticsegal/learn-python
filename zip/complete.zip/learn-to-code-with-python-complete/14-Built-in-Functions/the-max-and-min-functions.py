print(max([3, 5, 7]))
print(max(3, 5, 7, 9))
print(min([3, 5, 7]))
print(min(3, 5, 7))

print(max(["D", "Z", "K"]))
print(max("D", "Z", "K"))
print(min(["D", "Z", "K"]))
print(min("D", "Z", "K"))