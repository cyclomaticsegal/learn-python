print(sum([2, 3, 4]))
print(sum([-2, 3, -4]))

print(sum([-1.3, 4.6, 7.34]))