ice_cream_preferences = {
    "Benjamin": "Chocolate",
    "Sandy": "Vanilla",
    "Marv": "Cookies & Creme",
    "Julia": "Chocolate"
}

print(len(ice_cream_preferences))