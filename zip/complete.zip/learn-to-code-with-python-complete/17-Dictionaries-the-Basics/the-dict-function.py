print(list("abc"))
print(str(9))
print(dict()) # {}

employee_titles = [
    ["Mary", "Senior Manager"],
    ["Brian", "Vice President"],
    ["Julie", "Assistant Vice President"]
]

print(dict(employee_titles))