agents = { "Mulder", "Scully", "Doggett", "Reyes" }

# agents.remove("Doggett")
# print(agents)

# agents.remove("Skinner")

agents.discard("Doggett")
print(agents)

agents.discard("Skinner")
print(agents)