creator = "Boris"
PI = 3.14159

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def area(radius):
    return PI * radius * radius

_year = 2020