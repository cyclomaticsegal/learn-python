from calculator import creator, add, subtract
from math import sqrt
# from some_other_module import creator

print(creator)
print(add(2, 3))
print(subtract(10, 5))
print(sqrt(49))