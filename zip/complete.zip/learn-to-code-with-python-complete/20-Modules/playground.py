import math
import calculator

# import math, calculator
# print(math.__name__)
# print(calculator.__name__)
# print(__name__)

print(calculator.area(5))