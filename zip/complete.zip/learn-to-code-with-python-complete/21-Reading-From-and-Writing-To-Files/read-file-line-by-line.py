with open("cupcakes.txt") as file_object:
    for line in file_object:
        print(line.strip())