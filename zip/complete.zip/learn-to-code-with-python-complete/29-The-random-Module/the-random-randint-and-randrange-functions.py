import random

print(random.random() * 100)

print(random.randint(1, 5))

print(random.randrange(0, 50, 10))